---
name: code-review
description: Faz code review de um diff, PR ou ficheiros seguindo as regras do projeto (nomes, arquitetura, segurança, performance, testes). Use quando o utilizador pedir revisão de código, review de PR ou "revê isto".
---

# Code Review

Revê código como um dev sénior exigente mas construtivo. O objetivo é encontrar problemas reais, não reescrever o estilo de quem escreveu.

## Antes de começar

1. Procura regras do projeto: `CLAUDE.md`, `CONTRIBUTING.md`, `.editorconfig`, `docs/architecture*`. Se existirem, elas mandam sobre estas regras gerais.
2. Percebe o objetivo da mudança (título do PR, mensagem de commit, ou pergunta ao utilizador se não estiver claro).
3. Revê só o que mudou, mais o contexto necessário para entender.

## O que verificar (por ordem de prioridade)

1. **Correção** — bugs, condições de corrida, null/undefined, off-by-one, tratamento de erros em falta, exceções engolidas.
2. **Segurança** — input não validado, SQL/command injection, segredos no código, dados sensíveis em logs, autorização em falta.
3. **Arquitetura** — respeita as camadas do projeto? Lógica de negócio no sítio certo? Dependências na direção certa?
4. **Performance** — queries N+1, chamadas em loop, alocações desnecessárias, falta de async onde há I/O.
5. **Testes** — a mudança está coberta? Os testes testam comportamento ou implementação?
6. **Legibilidade** — nomes claros, métodos com uma responsabilidade, comentários que explicam o "porquê".

### Específico de .NET (se aplicável)
- `async void` fora de event handlers, `.Result`/`.Wait()` que podem causar deadlock
- `IDisposable` sem `using`
- `CancellationToken` não propagado
- EF Core: `ToList()` cedo demais, tracking desnecessário em leituras (`AsNoTracking`)
- Injeção de dependências com lifetimes errados (scoped dentro de singleton)

## Formato da resposta

Começa com um resumo de 1–2 linhas: o que a mudança faz e se está pronta para merge.

Depois lista os pontos agrupados por severidade:

- 🔴 **Bloqueante** — tem de ser corrigido antes do merge
- 🟡 **Sugestão** — melhoraria o código, mas não bloqueia
- 🟢 **Nitpick** — detalhe opcional

Para cada ponto: `ficheiro:linha`, o problema numa frase, e a correção proposta (com snippet curto quando ajudar).

Termina com o que está bem feito (1–2 pontos), se houver algo que valha a pena reconhecer.

## Regras

- Não inventes problemas para encher a lista. Se o código está bom, diz isso.
- Não comentes formatação que um linter/formatter resolve.
- Se não tens certeza de algo, diz que é uma dúvida e não uma afirmação.
