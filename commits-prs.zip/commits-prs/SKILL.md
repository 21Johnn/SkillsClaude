---
name: commits-prs
description: Escreve mensagens de commit (Conventional Commits) e descrições de Pull Request a partir do diff ou das alterações. Use quando o utilizador pedir mensagem de commit, descrição de PR, ou "faz o commit".
---

# Commits e Pull Requests

Gera mensagens de commit e descrições de PR claras, consistentes e no padrão da equipa.

## Antes de escrever

1. Se existir `CONTRIBUTING.md`, `CLAUDE.md` ou um template em `.github/pull_request_template.md`, segue esse padrão em vez deste.
2. Olha para as alterações: `git diff --cached` (commit) ou `git diff main...HEAD` (PR).
3. Olha para os últimos commits (`git log --oneline -10`) para copiar o estilo já usado no repositório.

## Mensagem de commit (Conventional Commits)

Formato:

```
<tipo>(<escopo>): <resumo no imperativo, até 72 caracteres>

<corpo opcional: o porquê da mudança, não o como>

<rodapé opcional: BREAKING CHANGE, Closes #123>
```

Tipos:
- `feat` — nova funcionalidade
- `fix` — correção de bug
- `refactor` — mudança de código sem alterar comportamento
- `test` — adicionar ou corrigir testes
- `docs` — só documentação
- `chore` — build, dependências, configs
- `perf` — melhoria de performance

Regras:
- Resumo no imperativo: "adiciona", "corrige" (ou "add", "fix" se o repo for em inglês)
- Sem ponto final no resumo
- Se o diff mistura coisas diferentes, sugere dividir em vários commits
- Mudanças que quebram compatibilidade levam `!` depois do tipo e `BREAKING CHANGE:` no rodapé

Exemplo:
```
feat(agendamento): adiciona cancelamento com reembolso parcial

Clientes que cancelam com mais de 24h de antecedência recebem 50%
de volta. Antes o cancelamento não devolvia nada.

Closes #142
```

## Descrição de Pull Request

```markdown
## O que muda
Resumo em 1–3 frases.

## Porquê
Contexto ou problema que motivou a mudança.

## Como testar
1. Passo a passo para validar
2. ...

## Checklist
- [ ] Testes adicionados/atualizados
- [ ] Sem segredos ou dados sensíveis no código
- [ ] Migrações de base de dados revistas (se houver)

## Notas para quem revê
Pontos onde queres atenção especial, decisões discutíveis.
```

## Regras gerais

- Escreve para quem vai ler daqui a 6 meses sem contexto
- Nunca inventes números de issue ou tickets
- Se não perceberes o objetivo de uma mudança pelo diff, pergunta antes de escrever
