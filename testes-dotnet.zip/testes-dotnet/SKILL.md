---
name: testes-dotnet
description: Escreve testes unitários e de integração em .NET com xUnit, seguindo o padrão Arrange-Act-Assert e as convenções do projeto. Use quando o utilizador pedir testes, cobertura ou "testa este método/classe" em C#.
---

# Testes em .NET (xUnit)

Escreve testes que testam comportamento, são fáceis de ler e não quebram com refactors.

## Antes de escrever

1. Procura o projeto de testes existente (`*.Tests.csproj`) e lê 1–2 ficheiros de teste para copiar o estilo: nomes, bibliotecas de mock e de asserts.
2. Usa as bibliotecas que o projeto já tem. Se não houver nada definido, usa:
   - xUnit
   - NSubstitute (mocks)
   - FluentAssertions ou asserts nativos do xUnit
3. Percebe o que o método deve fazer, não só o que faz hoje.

## Estrutura

- Uma classe de teste por classe testada: `PedidoServiceTests`
- Nome do teste: `Metodo_Cenario_ResultadoEsperado`
  - Ex.: `Cancelar_ComMaisDe24h_DevolveReembolsoParcial`
- Padrão AAA com linhas em branco a separar:

```csharp
[Fact]
public async Task Cancelar_ComMaisDe24h_DevolveReembolsoParcial()
{
    // Arrange
    var repo = Substitute.For<IAgendamentoRepository>();
    var agendamento = new Agendamento(dataHora: DateTime.UtcNow.AddHours(48), valor: 100m);
    repo.ObterAsync(agendamento.Id).Returns(agendamento);
    var sut = new AgendamentoService(repo);

    // Act
    var resultado = await sut.CancelarAsync(agendamento.Id);

    // Assert
    resultado.Reembolso.Should().Be(50m);
}
```

## O que cobrir

Para cada método público:
1. Caminho feliz
2. Limites (zero, vazio, máximo, exatamente na fronteira — ex.: 24h certas)
3. Inputs inválidos (null, negativos, IDs inexistentes)
4. Erros das dependências (repositório lança exceção, API externa falha)

Usa `[Theory]` com `[InlineData]` quando vários casos só mudam os valores.

## Regras

- Um comportamento por teste (vários asserts são OK se verificam a mesma coisa)
- Não testes métodos privados diretamente; testa através da API pública
- Não faças mock do que estás a testar nem de tipos simples (DTOs, value objects)
- Evita `DateTime.Now` no código testado; sugere `TimeProvider` se for preciso controlar o tempo
- Testes de integração com base de dados: `WebApplicationFactory` + Testcontainers, nunca a base de dados real de desenvolvimento
- Depois de escrever, corre `dotnet test` e confirma que passam antes de entregar
